#include <iostream>
#include "stdio.h"
using namespace std;
int main(){
char s[100], p[100];
int a, b, n, c, z;
a= 0;
gets(s);

for(int i = 0; s[i]!='\0';i++) {
c=i;

}
c++;
for(int i = c; i >= 0 ;i--) {
if ( (s[i] >= ' ') && (s[i] <= '/') || (s[i] >= ':' ) && (s[i] <= '@') || (s[i] >= '[' ) && (s[i] <= '`') || (s[i] >= '{' ) && (s[i] <= '~') || (i == 0) )
{

b=i;
if (i == 0)
b--;
for (int j = b + 1; j <= c; j++) {
	p[j]=s[j];
cout << p[j];

}
c=b ;
}
}
cin.get();cin.get();
return 0;
}

