#include <iostream>
#include <bitset>
#include <assert.h>
#include <stdio.h>
#include <iomanip>
using namespace std;
 	unsigned int g(unsigned int x, unsigned int n, unsigned int p);

int main()
{
 int x,n,p;
 //const int max_bit = 8;
 cin >> x >> n >> p;
 /*if (p > max_bit || (max_bit-p-n) <= 0)
	{
		cout << "lol!";
		system("pause");
		return 0;
	}*/
  cout << hex << g(x,n,p)<< endl;
  cout << dec << g(x,n,p);
  cin.get();cin.get();
}

unsigned int g(unsigned int x, unsigned int n, unsigned int p) {
  unsigned int sizeInt = sizeof(int)*8;

 if((p+n)>=sizeInt )
   return -1;
 unsigned int mask=((unsigned int)-1)>>(sizeInt -n);
	mask <<= p;
	return x | mask;
}

